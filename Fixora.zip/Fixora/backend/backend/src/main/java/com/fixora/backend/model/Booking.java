package com.fixora.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long requestId;
    private String date;
    private String time;
    private String status;

    public Booking() {
        this.status = "SCHEDULED";
    }

    public Booking(Long requestId, String date, String time) {
        this.requestId = requestId;
        this.date = date;
        this.time = time;
        this.status = "SCHEDULED";
    }

    public Long getId() {
        return id;
    }

    public Long getRequestId() {
        return requestId;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getStatus() {
        return status;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}