package com.fixora.backend;

import com.fixora.backend.model.Provider;
import com.fixora.backend.model.Review;
import com.fixora.backend.model.ServiceRequest;
import com.fixora.backend.repository.ProviderRepository;
import com.fixora.backend.repository.ReviewRepository;
import com.fixora.backend.repository.ServiceRequestRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin(origins = "http://localhost:5173")
public class ReviewController {

    private final ReviewRepository repository;
    private final ProviderRepository providerRepository;
    private final ServiceRequestRepository serviceRequestRepository;

    public ReviewController(
            ReviewRepository repository,
            ProviderRepository providerRepository,
            ServiceRequestRepository serviceRequestRepository) {

        this.repository = repository;
        this.providerRepository = providerRepository;
        this.serviceRequestRepository = serviceRequestRepository;
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping
    public Review createReview(@RequestBody Review review) {

        ServiceRequest request =
                serviceRequestRepository.findById(review.getRequestId())
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Service request not found"));

        if (!"COMPLETED".equals(request.getStatus())) {
            throw new RuntimeException(
                    "Review can only be submitted after service completion");
        }

        if (review.getRating() < 1 || review.getRating() > 5) {
            throw new RuntimeException(
                    "Rating must be between 1 and 5");
        }

        if (repository.existsByRequestId(review.getRequestId())) {
            throw new RuntimeException(
                    "This request has already been reviewed");
        }

        review.setProviderId(request.getProviderId());
        review.setCreatedAt(LocalDateTime.now());

        Review saved = repository.save(review);

        updateProviderRating(request.getProviderId());

        return saved;
    }

    @PreAuthorize("hasRole('PROVIDER')")
    @GetMapping("/provider/{providerId}")
    public List<Review> getProviderReviews(
            @PathVariable Long providerId) {

        return repository.findByProviderId(providerId);
    }

    private void updateProviderRating(Long providerId) {

        Provider provider =
                providerRepository.findById(providerId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Provider not found"));

        List<Review> reviews =
                repository.findByProviderId(providerId);

        if (!reviews.isEmpty()) {

            double average = reviews.stream()
                    .mapToInt(Review::getRating)
                    .average()
                    .orElse(provider.getRating());

            provider.setRating(
                    Math.round(average * 10.0) / 10.0
            );

            providerRepository.save(provider);
        }
    }
}