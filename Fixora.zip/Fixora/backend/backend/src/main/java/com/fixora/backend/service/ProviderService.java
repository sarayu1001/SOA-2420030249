package com.fixora.backend.service;

import com.fixora.backend.model.Provider;
import com.fixora.backend.repository.ProviderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProviderService {

    private final ProviderRepository repository;

    public ProviderService(ProviderRepository repository) {
        this.repository = repository;
    }

    public Provider createProvider(Provider provider) {
        return repository.save(provider);
    }

    public List<Provider> getAllProviders() {
        return repository.findAll();
    }
}