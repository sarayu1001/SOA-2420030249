package com.fixora.backend;

import com.fixora.backend.model.ServiceRequest;
import com.fixora.backend.repository.ServiceRequestRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/provider")
@CrossOrigin(origins = "http://localhost:5173")
public class ProviderRequestController {

    private final ServiceRequestRepository repository;

    public ProviderRequestController(ServiceRequestRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/requests")
    public List<ServiceRequest> getRequests() {
        return repository.findAll();
    }
}