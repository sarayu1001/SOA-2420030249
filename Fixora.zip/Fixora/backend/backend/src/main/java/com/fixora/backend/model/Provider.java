package com.fixora.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "providers")
public class Provider {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;

    private String name;
    private String serviceType;
    private String location;
    private double rating;
    private double price;

    public Provider() {
    }

    public Provider(String name, String serviceType, String location,
                     double rating, double price) {
        this.name = name;
        this.serviceType = serviceType;
        this.location = location;
        this.rating = rating;
        this.price = price;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getServiceType() {
        return serviceType;
    }

    public String getLocation() {
        return location;
    }

    public double getRating() {
        return rating;
    }

    public double getPrice() {
        return price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    public Long getUserId() {
    return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}