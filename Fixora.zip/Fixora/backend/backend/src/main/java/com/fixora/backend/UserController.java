package com.fixora.backend;

import com.fixora.backend.model.User;
import com.fixora.backend.service.JwtService;
import com.fixora.backend.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")
public class UserController {

    private final UserService service;
    private final JwtService jwtService;

    public UserController(UserService service, JwtService jwtService) {
        this.service = service;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return service.createUser(user);
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody User user) {

        User existingUser = service.findByEmail(user.getEmail());

        if (existingUser == null) {
            throw new RuntimeException("User not found");
        }

        if (!service.checkPassword(
                user.getPassword(),
                existingUser.getPassword())) {

            throw new RuntimeException("Invalid password");
        }

        String token = jwtService.generateToken(
                existingUser.getEmail(),
                existingUser.getRole()
        );

        Map<String, String> response = new HashMap<>();

        response.put("token", token);
        response.put("email", existingUser.getEmail());
        response.put("role", existingUser.getRole());
        response.put("userId", existingUser.getId().toString());

        return response;
    }
}