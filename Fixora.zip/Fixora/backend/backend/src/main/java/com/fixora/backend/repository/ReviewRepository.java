package com.fixora.backend.repository;

import com.fixora.backend.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByProviderId(Long providerId);
    boolean existsByRequestId(Long requestId);
}