package com.fixora.backend;

import com.fixora.backend.dto.MatchResult;
import com.fixora.backend.model.ServiceRequest;
import com.fixora.backend.service.MatchingService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/matching")
@CrossOrigin(origins = "http://localhost:5173")
public class MatchingController {

    private final MatchingService service;

    public MatchingController(MatchingService service) {
        this.service = service;
    }

    @PostMapping
    public List<MatchResult> findMatches(
            @RequestBody ServiceRequest request) {

        return service.findMatches(request);
    }
}