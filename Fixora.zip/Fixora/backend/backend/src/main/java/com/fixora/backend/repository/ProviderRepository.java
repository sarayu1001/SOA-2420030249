package com.fixora.backend.repository;

import com.fixora.backend.model.Provider;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ProviderRepository extends JpaRepository<Provider, Long> {
    List<Provider> findByServiceTypeIgnoreCaseAndLocationIgnoreCase(String serviceType, String location);
    Optional<Provider> findByUserId(Long userId);
}