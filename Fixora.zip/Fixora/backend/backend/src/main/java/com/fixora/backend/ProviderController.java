package com.fixora.backend;

import com.fixora.backend.model.Provider;
import com.fixora.backend.repository.ProviderRepository;
import com.fixora.backend.service.ProviderService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/providers")
@CrossOrigin(origins = "http://localhost:5173")
public class ProviderController {

    private final ProviderService service;
    private final ProviderRepository repository;

    public ProviderController(
            ProviderService service,
            ProviderRepository repository) {

        this.service = service;
        this.repository = repository;
    }

    @PostMapping
    public Provider createProvider(
            @RequestBody Provider provider) {

        return service.createProvider(provider);
    }

    @GetMapping
    public List<Provider> getAllProviders() {

        return service.getAllProviders();
    }

    // Find provider using the linked user ID
    @GetMapping("/user/{userId}")
    public Provider getProviderByUserId(
            @PathVariable Long userId) {

        return repository.findByUserId(userId)
                .orElseThrow(() ->
                        new RuntimeException("Provider not found"));
    }
}