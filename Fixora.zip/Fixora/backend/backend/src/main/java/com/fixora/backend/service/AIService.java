package com.fixora.backend.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class AIService {

    private final ChatClient chatClient;

    public AIService(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    public String analyzeProblem(String problem) {

        if (problem == null || problem.trim().isEmpty()) {
            return "INVALID";
        }

        String text = problem.trim().toLowerCase();

        // Invalid / meaningless input
        if (text.length() < 3) {
            return "INVALID";
        }

        if (text.matches("^[^a-zA-Z]*$")) {
            return "INVALID";
        }

        // Normal / non-service statements
        if (text.contains("working fine")
        || text.contains("working perfectly")
        || text.contains("works fine")
        || text.contains("works perfectly")
        || text.contains("is working")
        || text.contains("perfectly working")
        || text.contains("is fine")
        || text.endsWith("fine")
        || text.contains("no problem")
        || text.contains("no issue")
        || text.contains("nothing wrong")) {

    return "NONE";
}

        // Health / personal problems
        if (text.matches(".*\\b(head|headache|stomach|fever|pain|paining|doctor|medicine|sick|cold|cough)\\b.*")) {
            return "NONE";
        }

        // Plumbing
        if (text.matches(".*\\b(tap|faucet|pipe|sink|toilet|drain|water leak|leaking water|leak|shower|tub)\\b.*")) {
            return "Plumbing";
        }

        // Electrical
        if (text.matches(".*\\b(fan|light|switch|socket|wiring|electricity|power|spark|sparking|electric)\\b.*")) {
            return "Electrical";
        }

        // HVAC
        if (text.matches(".*\\b(ac|air conditioner|air conditioning|cooler|heating)\\b.*")) {
            return "HVAC";
        }

        // Appliances
        if (text.matches(".*\\b(fridge|refrigerator|washing machine|microwave|oven|dishwasher|mixer|television|tv|air fryer)\\b.*")) {
            return "Appliance Repair";
        }

        // Carpentry
        if (text.matches(".*\\b(door|cupboard|furniture|table|chair|wood|wooden|window)\\b.*")) {
            return "Carpentry";
        }

        // Painting
        if (text.matches(".*\\b(paint|painting|repaint|wall color|color wall|color)\\b.*")) {
            return "Painting";
        }

        // Cleaning
        if (text.matches(".*\\b(clean|cleaning|dirty|deep clean|dirt|trash|trash bin|mop|mopping|sweeping|sweep)\\b.*")) {
            return "Cleaning";
        }

        // Pest Control
        if (text.matches(".*\\b(cockroach|cockroaches|termite|ants|rat|rats|pest|insects|flies|bugs)\\b.*")) {
            return "Pest Control";
        }

        // Locksmith
        if (text.matches(".*\\b(lock|locked|key|door lock|locked door)\\b.*")) {
            return "Locksmith";
        }

        // Water Purifier
        if (text.matches(".*\\b(ro|water purifier|purifier|filter|filter water|water filter)\\b.*")) {
            return "Water Purifier";
        }

        // Internet
        if (text.matches(".*\\b(wifi|wi-fi|router|internet|broadband|cable)\\b.*")) {
            return "Home Internet";
        }

        // Solar
        if (text.matches(".*\\b(solar|solar panel)\\b.*")) {
            return "Solar";
        }

        // Gardening
        if (text.matches(".*\\b(garden|gardening|plants|lawn|flowering)\\b.*")) {
            return "Gardening";
        }

        // CCTV / Security
        if (text.matches(".*\\b(cctv|security camera|camera|survailance)\\b.*")) {
            return "CCTV and Security";
        }

        // Use Ollama only when the problem is unclear
        String prompt = """
                You are Fixora AI, a home repair service classifier.

                Classify the customer's message into exactly ONE category.

                Categories:
                Plumbing
                Electrical
                HVAC
                Appliance Repair
                Carpentry
                Painting
                Masonry
                Roofing
                Glass Repair
                Locksmith
                Pest Control
                Cleaning
                Home Internet
                Solar
                Gardening
                Water Purifier
                CCTV and Security
                Other
                NONE

                Return NONE if it is not a home repair or maintenance problem.

                Return ONLY the category name.

                Customer message:
                %s
                """.formatted(problem);

        try {
            String result = chatClient
                    .prompt()
                    .user(prompt)
                    .call()
                    .content()
                    .trim();

            String[] categories = {
                    "Plumbing",
                    "Electrical",
                    "HVAC",
                    "Appliance Repair",
                    "Carpentry",
                    "Painting",
                    "Masonry",
                    "Roofing",
                    "Glass Repair",
                    "Locksmith",
                    "Pest Control",
                    "Cleaning",
                    "Home Internet",
                    "Solar",
                    "Gardening",
                    "Water Purifier",
                    "CCTV and Security",
                    "Other",
                    "NONE"
            };

            for (String category : categories) {
                if (result.equalsIgnoreCase(category)) {
                    return category;
                }
            }

            return "UNCLEAR";

        } catch (Exception e) {
        e.printStackTrace();
        return "UNCLEAR";
        }
    }
}