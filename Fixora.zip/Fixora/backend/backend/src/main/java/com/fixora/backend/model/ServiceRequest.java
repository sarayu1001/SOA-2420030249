package com.fixora.backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "service_requests")
public class ServiceRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String serviceType;
    private String location;
    private String urgency;
    private String description;
    private String status;
    private Long providerId;
    
    public Long getProviderId() {
    return providerId;
}

public void setProviderId(Long providerId) {
    this.providerId = providerId;
}

    public ServiceRequest() {
        this.status = "PENDING";
    }

    public ServiceRequest(String serviceType, String location,
                           String urgency, String description) {
        this.serviceType = serviceType;
        this.location = location;
        this.urgency = urgency;
        this.description = description;
        this.status = "PENDING";
    }

    public Long getId() {
        return id;
    }

    public String getServiceType() {
        return serviceType;
    }

    public String getLocation() {
        return location;
    }

    public String getUrgency() {
        return urgency;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setUrgency(String urgency) {
        this.urgency = urgency;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}