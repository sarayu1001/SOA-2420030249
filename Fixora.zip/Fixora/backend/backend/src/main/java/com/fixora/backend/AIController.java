package com.fixora.backend;

import com.fixora.backend.service.AIService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "http://localhost:5173")
public class AIController {

    private final AIService aiService;

    public AIController(AIService aiService) {
        this.aiService = aiService;
    }

    @PostMapping("/analyze")
    public Map<String, String> analyze(
            @RequestBody Map<String, String> request) {

        String problem = request.get("problem");

        String serviceType = aiService.analyzeProblem(problem);

        System.out.println(
                "AI INPUT: " + problem +
                " -> AI RESULT: " + serviceType
        );

        return Map.of(
                "problem", problem,
                "serviceType", serviceType
        );
    }
}