package com.fixora.backend;

import com.fixora.backend.model.ServiceRequest;
import com.fixora.backend.repository.ServiceRequestRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
@CrossOrigin(origins = "http://localhost:5173")
public class ServiceRequestController {

    private final ServiceRequestRepository repository;

    public ServiceRequestController(ServiceRequestRepository repository) {
        this.repository = repository;
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping
    public ServiceRequest createRequest(@RequestBody ServiceRequest request) {
        if (request.getStatus() == null || request.getStatus().isBlank()) {
            request.setStatus("PENDING");
        }
        return repository.save(request);
    }

    @GetMapping
    public List<ServiceRequest> getRequests() {
        return repository.findAll();
    }

    @PreAuthorize("hasRole('PROVIDER')")
    @PutMapping("/{id}/status")
    public ServiceRequest updateStatus(
            @PathVariable Long id,
            @RequestParam String status) {

        ServiceRequest request = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Request not found"));

        String current = request.getStatus();

        boolean valid =
                ("PENDING".equals(current) &&
                        ("ACCEPTED".equals(status)
                                || "REJECTED".equals(status))) ||
                ("ACCEPTED".equals(current)
                        && "IN PROGRESS".equals(status)) ||
                ("IN PROGRESS".equals(current)
                        && "COMPLETED".equals(status));

        if (!valid) {
            throw new RuntimeException("Invalid status change");
        }

        request.setStatus(status);
        return repository.save(request);
    }

    @PreAuthorize("hasRole('CUSTOMER')")
    @PutMapping("/{id}/provider")
    public ServiceRequest assignProvider(
            @PathVariable Long id,
            @RequestParam Long providerId) {

        ServiceRequest request = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Request not found"));

        String current = request.getStatus();

        if (!"PENDING".equals(current)
                && !"REJECTED".equals(current)) {
            throw new RuntimeException(
                    "Provider can only be selected for pending or rejected requests");
        }

        request.setProviderId(providerId);
        request.setStatus("PENDING");

        return repository.save(request);
    }

    @PreAuthorize("hasRole('PROVIDER')")
    @GetMapping("/provider/{providerId}")
    public List<ServiceRequest> getProviderRequests(
            @PathVariable Long providerId) {
        return repository.findByProviderId(providerId);
    }
}