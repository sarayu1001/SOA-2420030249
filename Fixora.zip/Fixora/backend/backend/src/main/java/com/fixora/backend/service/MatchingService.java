package com.fixora.backend.service;

import com.fixora.backend.dto.MatchResult;
import com.fixora.backend.model.Provider;
import com.fixora.backend.model.ServiceRequest;
import com.fixora.backend.repository.ProviderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MatchingService {

    private final ProviderRepository providerRepository;

    public MatchingService(ProviderRepository providerRepository) {
        this.providerRepository = providerRepository;
    }

    public List<MatchResult> findMatches(ServiceRequest request) {

        List<Provider> providers =
                providerRepository
                        .findByServiceTypeIgnoreCaseAndLocationIgnoreCase(
                                request.getServiceType(),
                                request.getLocation()
                        );

        return providers.stream()
                .map(provider ->
                        new MatchResult(provider, calculateScore(provider)))
                .sorted((a, b) ->
                        Double.compare(b.getMatchScore(), a.getMatchScore()))
                .toList();
    }

    private double calculateScore(Provider provider) {

        double ratingScore = provider.getRating() * 15;

        double priceScore =
                Math.max(0, 1000 - provider.getPrice()) / 20;

        return Math.min(100, ratingScore + priceScore);
    }
}