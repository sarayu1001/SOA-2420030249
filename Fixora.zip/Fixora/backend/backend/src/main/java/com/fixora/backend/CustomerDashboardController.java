package com.fixora.backend;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/customer")
public class CustomerDashboardController {

    @GetMapping("/dashboard")
    public String dashboard() {
        return "Customer dashboard - access granted";
    }
}