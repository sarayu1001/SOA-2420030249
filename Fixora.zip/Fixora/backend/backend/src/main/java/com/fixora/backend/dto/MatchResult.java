package com.fixora.backend.dto;

import com.fixora.backend.model.Provider;

public class MatchResult {

    private Provider provider;
    private double matchScore;

    public MatchResult(Provider provider, double matchScore) {
        this.provider = provider;
        this.matchScore = matchScore;
    }

    public Provider getProvider() {
        return provider;
    }

    public double getMatchScore() {
        return matchScore;
    }
}