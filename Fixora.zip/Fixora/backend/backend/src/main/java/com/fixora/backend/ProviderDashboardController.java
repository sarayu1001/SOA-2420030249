package com.fixora.backend;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/provider")
public class ProviderDashboardController {

    @GetMapping("/dashboard")
    public String dashboard() {
        return "Provider dashboard - access granted";
    }
}