import { useState, useEffect } from "react";
import "./App.css";

import {
    login,
    register,
    findMatches,
    analyzeProblem,
    createRequest,
    getRequests,
    getProviders,
    updateRequestStatus,
    createBooking,
    getBookings,
    assignProvider,
    getProviderRequests,
    createReview,
    getProviderReviews
} from "./api";
function App() {

    const [message, setMessage] = useState("");
    const [providerRequests, setProviderRequests] = useState([]);
    const [isLoggedIn, setIsLoggedIn] = useState(
        
    !!localStorage.getItem("token")
);
const [selectedRole, setSelectedRole] = useState("CUSTOMER");
const [userRole, setUserRole] = useState(
    localStorage.getItem("role") || ""
);
const [assignedProviderName, setAssignedProviderName] = useState("");
const [showLogin, setShowLogin] = useState(false);

const [authData, setAuthData] = useState({
    name: "",
    email: "",
    password: ""
});

const [authMode, setAuthMode] = useState("login");

    const [messages, setMessages] = useState([
        {
            type: "bot",
            text: "Hi! I'm Fixora AI. Tell me about your home repair problem."
        }
    ]);

    const [providers, setProviders] = useState([]);
    const [recommendedProviders, setRecommendedProviders] = useState([]);

    const [requests, setRequests] = useState([]);

    const [loading, setLoading] = useState(false);

    const [selectedRequest, setSelectedRequest] = useState(null);

    const [scheduleDate, setScheduleDate] = useState("");

    const [scheduleTime, setScheduleTime] = useState("");

    const [showHistory, setShowHistory] = useState(false);

    const [bookingService, setBookingService] = useState("");

    const [booking, setBooking] = useState(null);
    const [selectedProvider, setSelectedProvider] = useState(null);
    const [providerSearch, setProviderSearch] = useState("");
    const [showNotifications, setShowNotifications] =
    useState(false);

const [selectedPhoto, setSelectedPhoto] =
    useState(null);

const [estimatedPrice, setEstimatedPrice] =
    useState(null);

const [paymentStatus, setPaymentStatus] =
    useState("PENDING");

const [invoiceVisible, setInvoiceVisible] =
    useState(false);

const [favoriteProviders, setFavoriteProviders] =
    useState(
        JSON.parse(
            localStorage.getItem(
                "fixoraFavorites"
            ) || "[]"
        )
    );

const [notifications, setNotifications] =
    useState([]);

const [reviewRating, setReviewRating] = useState(5);
const [reviewFeedback, setReviewFeedback] = useState("");
const [reviewingRequestId, setReviewingRequestId] = useState(null);
const [providerReviews, setProviderReviews] = useState([]);
// Load saved requests and all providers
useEffect(() => {
    if (!isLoggedIn) return;

    loadRequests();

    getProviders()
        .then(data => setProviders(data))
        .catch(error =>
            console.error("Provider loading failed:", error)
        );

    if (userRole === "PROVIDER") {
        getRequests()
            .then(data => setProviderRequests(data))
            .catch(error =>
                console.error("Provider requests error:", error)
            );
    }
}, [isLoggedIn, userRole]);
// Automatically refresh customer tracking
useEffect(() => {
    if (!isLoggedIn) return;

    const interval = setInterval(() => {
        loadRequests();
    }, 3000);

    return () => clearInterval(interval);
}, [isLoggedIn]);
// Get requests from backend
const loadRequests = async () => {
    try {
        const result = await getRequests();
        result.sort((a, b) => Number(b.id) - Number(a.id));
        setRequests(result);
    } catch (error) {
        console.error("Failed to load requests:", error);
    }
};


    // Detect urgency
    const detectUrgency = (text) => {

        const value = text.toLowerCase();

        if (
            value.includes("emergency") ||
            value.includes("urgent") ||
            value.includes("immediately") ||
            value.includes("danger") ||
            value.includes("fire") ||
            value.includes("flood") ||
            value.includes("sparking") ||
            value.includes("badly")
        ) {

            return "High";

        }

        if (
            value.includes("soon") ||
            value.includes("quickly")
        ) {

            return "Medium";

        }

        return "Low";

    };

const handleAuth = async () => {
    try {
        if (authMode === "register") {
            await register({
                name: authData.name,
                email: authData.email,
                password: authData.password
            });

            alert("Registration successful. Please login.");

            setAuthMode("login");

            setAuthData({
                name: "",
                email: authData.email,
                password: ""
            });
        } else {
            const data = await login({
                email: authData.email,
                password: authData.password
            });

            if (data.role !== selectedRole) {
                alert(
                    `This account is registered as ${data.role}. Please select the correct role.`
                );

                localStorage.removeItem("token");
                localStorage.removeItem("role");
                localStorage.removeItem("email");
                localStorage.removeItem("userId");

                return;
            }

            setUserRole(data.role);
            setIsLoggedIn(true);
            setAuthData({
                name: "",
                email: "",
                password: ""
            });
        }
    } catch (error) {
        alert(error.message);
    }
};
const calculateEstimatedPrice = (
    serviceType,
    urgency
) => {

    const prices = {
        "Plumbing": 700,
        "Electrical": 800,
        "HVAC": 1200,
        "Appliance Repair": 1000,
        "Carpentry": 900,
        "Painting": 1500,
        "Cleaning": 600,
        "Pest Control": 800,
        "Locksmith": 500,
        "Roofing": 1500,
        "Glass Repair": 800,
        "Home Internet": 600,
        "Solar": 1800,
        "Gardening": 500,
        "Water Purifier": 700,
        "CCTV and Security": 1200
    };

    const base =
        prices[serviceType] || 800;

    if (urgency === "High") {
        return {
            min: base + 200,
            max: base + 700
        };
    }

    if (urgency === "Medium") {
        return {
            min: base,
            max: base + 500
        };
    }

    return {
        min: base,
        max: base + 400
    };
};
    // Send user's repair problem
    const sendMessage = async () => {

        if (!message.trim() || loading) return;

        const userMessage = message.trim();

        // Show user message
        setMessages((prev) => [
            ...prev,
            {
                type: "user",
                text: userMessage
            }
        ]);

        setMessage("");

        setLoading(true);

        try {

            // 1. AI analyzes the problem
            const aiResult = await analyzeProblem(userMessage);
            console.log("AI RESULT:", aiResult);

            const serviceType =
            aiResult.serviceType.trim();

        // Stop invalid / non-service / unclear requests
        if (
            serviceType === "INVALID" ||
            serviceType === "NONE" ||
            serviceType === "UNCLEAR"
        ) {

            let responseMessage = "";

            if (serviceType === "INVALID") {
                responseMessage =
                    "Please enter a meaningful home repair problem.";
            }

            if (serviceType === "NONE") {
                responseMessage =
                    "This does not appear to be a home repair or maintenance request.";
            }

            if (serviceType === "UNCLEAR") {
                responseMessage =
                    "Please describe your home repair problem in a little more detail.";
            }

            setMessages((prev) => [
                ...prev,
                {
                    type: "bot",
                    text: responseMessage
                }
            ]);

            setLoading(false);
            return;
        }

        // 2. Detect urgency
        const urgency =
            detectUrgency(userMessage);
            const priceEstimate =
    calculateEstimatedPrice(
        serviceType,
        urgency
    );

setEstimatedPrice(priceEstimate);
setNotifications(prev => [
    {
        id: Date.now(),
        text: "Your service request was created successfully.",
        time: new Date().toLocaleTimeString()
    },
    ...prev
]);

        // 3. Create request
        const request = {

            serviceType: serviceType,

            location: "Hyderabad",

            urgency: urgency,

            description: userMessage
        };

            // 4. Save request in PostgreSQL
            const savedRequest =
                await createRequest(request);

            // Add new request to frontend
            setRequests((prev) => [
                ...prev,
                savedRequest
            ]);

            // 5. Find suitable providers
            const result = await findMatches(request);
console.log("MATCH RESULT:", result);

setRecommendedProviders(result);

// Automatically assign only when there is exactly one matching business.
if (result.length === 1) {
    const onlyProvider = result[0].provider || result[0];
    setAssignedProviderName(onlyProvider.name);

    const assignedRequest = await assignProvider(
        savedRequest.id,
        onlyProvider.id
    );

    const finalAssignedRequest = {
        ...assignedRequest,
        providerId: onlyProvider.id
    };

    setRequests(prev =>
        prev.map(r =>
            r.id === finalAssignedRequest.id
                ? finalAssignedRequest
                : r
        )
    );

    setSelectedRequest(finalAssignedRequest);

} else if (result.length > 1) {

    // Multiple providers → customer selects one
    setAssignedProviderName("");
    setSelectedRequest(savedRequest);

} else {

    // No providers
    setSelectedRequest(savedRequest);
}

if (userRole === "PROVIDER") {
    try {
        const allRequests = await getRequests();
        setProviderRequests(allRequests);
    } catch (error) {
        console.error("Failed to load provider requests:", error);
    }
}

            // 6. AI response
            setMessages((prev) => [
                ...prev,
                {
                    type: "bot",

                    text:
                        result.length > 0
                            ? `I identified this as a ${serviceType} issue. I found ${result.length} suitable provider${result.length > 1 ? "s" : ""} for you.`
                            : `I identified this as a ${serviceType} issue, but I couldn't find a provider in Hyderabad yet.`
                }
            ]);

       } catch (error) {

    console.error("FIXORA ERROR:", error);

    setMessages((prev) => [
        ...prev,
        {
            type: "bot",
            text: "Something went wrong. Please try again."
        }
    ]);

}
        setLoading(false);

    };


    // Update service request status
    const changeStatus = async (requestId, newStatus) => {
    try {
        const updated = await updateRequestStatus(
            requestId,
            newStatus
        );

        setRequests(prev =>
            prev.map(request =>
                request.id === updated.id
                    ? updated
                    : request
            )
        );

        // Refresh provider requests
        if (userRole === "PROVIDER") {
            const data = await getRequests();
            setProviderRequests(data);
        }

    } catch (error) {
        console.error("Status update failed:", error);
        alert("Unable to update status");
    }
};
const assignProviderToRequest = async (requestId, providerId) => {
    try {
        const updatedRequest =
            await assignProvider(requestId, providerId);

        setRequests(prev =>
            prev.map(request =>
                request.id === updatedRequest.id
                    ? updatedRequest
                    : request
            )
        );

        setSelectedRequest(updatedRequest);
        setAssignedProviderName(
            providers.find(p => p.id === providerId)?.name || ""
        );

        return updatedRequest;

    } catch (error) {
        console.error("Provider assignment failed:", error);
        alert("Failed to assign provider.");
        return null;
    }
};

    // Schedule service
const scheduleService = async () => {

    if (!selectedRequest) {
        alert("Please select a request.");
        return;
    }

    if (!scheduleDate || !scheduleTime) {
        alert("Please select date and time.");
        return;
    }

    try {

        const bookingData = {
            requestId: selectedRequest.id,
            date: scheduleDate,
            time: scheduleTime
        };

        const savedBooking = await createBooking(bookingData);

        setBookingService(selectedRequest.serviceType);
        setBooking(savedBooking);

        alert(
            `Service scheduled for ${scheduleDate} at ${scheduleTime}`
        );

        setSelectedRequest(null);
        setScheduleDate("");
        setScheduleTime("");

    } catch (error) {

        console.error("Booking failed:", error);

        alert("Failed to schedule service.");

    }
};
       
        

    // Contact provider
    const contactProvider = (provider) => {

        alert(
            `Contacting ${provider.name}`
        );

    };


    // Get status description
    const getStatusMessage = (status) => {

        if (status === "PENDING") {

            return "Waiting for provider acceptance";

        }

        if (status === "ACCEPTED") {

            return "Provider accepted your request";

        }

        if (status === "IN PROGRESS") {

            return "Service is currently in progress";

        }

        if (status === "COMPLETED") {

            return "Service completed successfully";

        }

        if (status === "REJECTED") {

            return "The selected provider rejected this request";

        }

        return "Request created";

    };
    const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("email");
    localStorage.removeItem("userId");

    setIsLoggedIn(false);
    setUserRole("");
    setSelectedRole("CUSTOMER");
};


    return (
    <>
        {!isLoggedIn && (
            <div className="auth-box">
                <h2>
                    {authMode === "login"
                        ? "Login to Fixora"
                        : "Create Account"}
                </h2>
                {authMode === "login" && (
                    <div className="role-selector">
                        <button
                            className={selectedRole === "CUSTOMER" ? "role-active" : ""}
                            onClick={() => setSelectedRole("CUSTOMER")}
                        >
                            Customer
                        </button>

                        <button
                            className={selectedRole === "PROVIDER" ? "role-active" : ""}
                            onClick={() => setSelectedRole("PROVIDER")}
                        >
                            Provider
                        </button>

                        
                    </div>
                )}

                {authMode === "register" && (
                    <input
                        type="text"
                        placeholder="Name"
                        value={authData.name}
                        onChange={(e) =>
                            setAuthData({
                                ...authData,
                                name: e.target.value
                            })
                        }
                    />
                )}

                <input
                    type="email"
                    placeholder="Email"
                    value={authData.email}
                    onChange={(e) =>
                        setAuthData({
                            ...authData,
                            email: e.target.value
                        })
                    }
                />

                <input
                    type="password"
                    placeholder="Password"
                    value={authData.password}
                    onChange={(e) =>
                        setAuthData({
                            ...authData,
                            password: e.target.value
                        })
                    }
                />

                <button onClick={handleAuth}>
                    {authMode === "login"
                        ? "Login"
                        : "Register"}
                </button>

                <button
                    className="secondary"
                    onClick={() =>
                        setAuthMode(
                            authMode === "login"
                                ? "register"
                                : "login"
                        )
                    }
                >
                    {authMode === "login"
                        ? "Create Account"
                        : "Back to Login"}
                </button>
            </div>
        )}

        {isLoggedIn && userRole === "CUSTOMER" && (
            <div className="app">


            {/* HEADER */}

            <header className="header">
                {isLoggedIn && (
    <button
        className="secondary"
        onClick={() => {
            localStorage.removeItem("token");
            setIsLoggedIn(false);
        }}
    >
        Logout
    </button>
)}

                <div className="logo">

                    <span>🔧</span>

                    <div>

                        <h1>Fixora AI</h1>

                        <p>
                            Smart Home Repair Assistant
                        </p>

                    </div>

                </div>


                <div className="status">

                    <span className="status-dot"></span>

                    AI Online

                </div>

            </header>



            {/* MAIN */}

            <main className="chat-container">


                {/* WELCOME */}

                <div className="welcome">

                    <div className="bot-icon">
                        🤖
                    </div>

                    <h2>
                        How can I help you today?
                    </h2>

                    <p>
                        Describe any home repair problem
                        naturally and Fixora AI will identify
                        the required professional service.
                    </p>

                    <div className="service-shortcuts" aria-label="Popular home services">
                        <span className="service-shortcut"><span>🔧</span> Plumbing</span>
                        <span className="service-shortcut"><span>⚡</span> Electrical</span>
                        <span className="service-shortcut"><span>🧺</span> Appliances</span>
                        <span className="service-shortcut"><span>🪚</span> Carpentry</span>
                    </div>

                </div>



                {/* CHAT */}

                <div className="chat-box">


                    {messages.map(
                        (msg, index) => (

                            <div
                                key={index}
                                className={`message ${msg.type}`}
                            >

                                {msg.type === "bot" && (

                                    <div className="avatar">
                                        🤖
                                    </div>

                                )}

                                <div className="bubble">
                                    {msg.text}
                                </div>

                            </div>

                        )
                    )}



                    {/* LOADING */}

                    {loading && (

                        <div className="message bot">

                            <div className="avatar">
                                🤖
                            </div>

                            <div className="bubble">

                                AI is analyzing your
                                problem...

                            </div>

                        </div>

                    )}



                    {/* PROVIDERS */}

                    {recommendedProviders.length > 0 && (

                        <div className="provider-section">

                            <h2>
                                Recommended Professionals
                            </h2>


                           {recommendedProviders.map((match) => {
                                 const provider = match.provider || match;

                                return (
                                    


                                    <div
                                        className="provider-card"
                                        key={provider.id}
                                    >


                                        <div className="provider-header">

                                            <div className="provider-icon">
                                                🔧
                                            </div>

                                            <div>

                                                <h3>
                                                    {provider.name}
                                                </h3>

                                                <span className="recommended">
                                                    AI Recommended
                                                </span>

                                            </div>

                                        </div>



                                        <div className="provider-details">


                                            <div>

                                                <span>
                                                    🛠️
                                                </span>

                                                <div>

                                                    <small>
                                                        Service
                                                    </small>

                                                    <strong>
                                                        {provider.serviceType}
                                                    </strong>

                                                </div>

                                            </div>



                                            <div>

                                                <span>
                                                    📍
                                                </span>

                                                <div>

                                                    <small>
                                                        Location
                                                    </small>

                                                    <strong>
                                                        {provider.location}
                                                    </strong>

                                                </div>

                                            </div>



                                            <div>

                                                <span>
                                                    ⭐
                                                </span>

                                                <div>

                                                    <small>
                                                        Rating
                                                    </small>

                                                    <strong>
                                                        {provider.rating}
                                                    </strong>

                                                </div>

                                            </div>



                                            <div>

                                                <span>
                                                    ₹
                                                </span>

                                                <div>

                                                    <small>
                                                        Estimated Price
                                                    </small>

                                                    <strong>
                                                        ₹{provider.price}
                                                    </strong>

                                                </div>

                                            </div>


                                        </div>



                                        <div className="provider-actions">

    <button
        onClick={() =>
            contactProvider(provider)
        }
    >
        Contact Provider
    </button>

    {selectedRequest &&
        (selectedRequest.status === "REJECTED" || !selectedRequest.providerId) && (
        <button
            onClick={async () => {
                const updated = await assignProviderToRequest(
                    selectedRequest.id,
                    provider.id
                );
                if (updated) {
                    setRecommendedProviders([]);
                    await loadRequests();
                    setSelectedRequest(null);
                    alert(`Assigned ${provider.name} to your request.`);
                }
            }}
        >
            Select Provider
        </button>
    )}
                                            <button
                                                className="secondary"
                                                onClick={() => {
                                                    const request = requests[requests.length - 1];
                                                    setSelectedRequest(request);
                                                }}
                                            >
                                                Schedule Service
                                            </button>


                                        </div>


                                         </div>
                                );
                            }
                        )}

                    </div>

                )}
                
             
            </div>
            



                {/* SCHEDULED BOOKING */}

                {booking && (

                    <div className="tracking-card">

                        <h2>
                            Scheduled Service
                        </h2>

                        <p>
                            <strong>Service:</strong>{" "}
                            {bookingService}
                        </p>

                        <p>
                            <strong>Date:</strong>{" "}
                            {booking.date}
                        </p>

                        <p>
                            <strong>Time:</strong>{" "}
                            {booking.time}
                        </p>

                        <p>
                            <strong>Status:</strong>{" "}
                            {booking.status}
                        </p>

                    </div>

                )}


                


                {/* SCHEDULING */}

                {selectedRequest && (

                    <div className="schedule-section">

                        <h2>
                            Schedule Service
                        </h2>

                        <p>
                            {selectedRequest.serviceType} service
                        </p>


                        <label>
                            Select Date
                        </label>

                        <input
                            type="date"
                            value={scheduleDate}
                            onChange={(e) =>
                                setScheduleDate(
                                    e.target.value
                                )
                            }
                        />


                        <label>
                            Select Time
                        </label>

                        <input
                            type="time"
                            value={scheduleTime}
                            onChange={(e) =>
                                setScheduleTime(
                                    e.target.value
                                )
                            }
                        />


                        <div className="schedule-actions">

                            <button
                                onClick={scheduleService}
                            >
                                Confirm Schedule
                            </button>


                            <button
                                className="secondary"
                                onClick={() =>
                                    setSelectedRequest(
                                        null
                                    )
                                }
                            >
                                Cancel
                            </button>

                        </div>

                    </div>

                )}



                {/* INPUT */}

                <div className="input-area">

                    <textarea
                        className="problem-textarea"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                sendMessage();
                            }
                        }}
                        placeholder="Describe your home repair problem..."
                        rows={2}
                    />

<label className="photo-upload">
    📷 Add Problem Photo

    <input
        type="file"
        accept="image/*"
        hidden
        onChange={(e) => {
            const file = e.target.files?.[0];

            if (file) {
                setSelectedPhoto(
                    URL.createObjectURL(file)
                );
            }
        }}
    />
</label>

{selectedPhoto && (
    <div className="photo-preview">
        <img
            src={selectedPhoto}
            alt="Problem"
        />

        <button
            onClick={() => setSelectedPhoto(null)}
        >
            Remove
        </button>
    </div>
)}


                    <button
                        onClick={sendMessage}
                        disabled={loading}
                    >
                        ➤
                    </button>

                </div>



                <p className="hint">

                    Try:
                    "My kitchen pipe is leaking badly"

                    {" "}or{" "}

                    "My AC is running but not cooling"

                </p>

                {/* SERVICE TRACKING */}

                {requests.length > 0 && (

                    <div className="tracking-section">


                        <div className="tracking-header">

                            <h2>
                                Service Tracking
                            </h2>

                            <button
                                onClick={() =>
                                    setShowHistory(
                                        !showHistory
                                    )
                                }
                            >
                                {showHistory
                                    ? "Hide History"
                                    : "View History"}
                            </button>

                        </div>



                        {/* LATEST REQUEST */}

                        {!showHistory && (

                            <div className="tracking-card">

                                {(() => {

                                    const request =
                                        [...requests].sort(
                                            (a, b) => Number(b.id) - Number(a.id)
                                        )[0];

                                    return (

                                        <>

                                            <h3>
                                                {request.serviceType}
                                            </h3>

                                            <p>
                                                {request.description}
                                            </p>


                                            <p>
                                                <strong>
                                                    Location:
                                                </strong>{" "}
                                                {request.location}
                                            </p>


                                            <p>
                                                <strong>
                                                    Urgency:
                                                </strong>{" "}
                                                {request.urgency}
                                            </p>


                                            <p>
                                                <strong>
                                                    Status:
                                                </strong>{" "}
                                                {request.status}
                                            </p>
                                            {request.providerId && (
                                            <p>
                                                <strong>Assigned Provider:</strong>{" "}
                                                {providers.find(
                                                    p => Number(p.id) === Number(request.providerId)
                                                )?.name || "Provider Assigned"}
                                            </p>
                                        )}


                                            <p>
                                                {getStatusMessage(
                                                    request.status
                                                )}
                                            </p>



                                            {/* STATUS FLOW */}

                                            <div className="status-flow">

                                                <span
                                                    className={
                                                        request.status === "PENDING" ||
                                                        request.status === "ACCEPTED" ||
                                                        request.status === "IN PROGRESS" ||
                                                        request.status === "COMPLETED"
                                                            ? "active"
                                                            : ""
                                                    }
                                                >
                                                    PENDING
                                                </span>


                                                <span>→</span>


                                                <span
                                                    className={
                                                        request.status === "ACCEPTED" ||
                                                        request.status === "IN PROGRESS" ||
                                                        request.status === "COMPLETED"
                                                            ? "active"
                                                            : ""
                                                    }
                                                >
                                                    ACCEPTED
                                                </span>


                                                <span>→</span>


                                                <span
                                                    className={
                                                        request.status === "IN PROGRESS" ||
                                                        request.status === "COMPLETED"
                                                            ? "active"
                                                            : ""
                                                    }
                                                >
                                                    IN PROGRESS
                                                </span>


                                                <span>→</span>


                                                <span
                                                    className={
                                                        request.status === "COMPLETED"
                                                            ? "active"
                                                            : ""
                                                    }
                                                >
                                                    COMPLETED
                                                </span>

                                            </div>



                                            {/* STATUS BUTTONS */}

                                           
                                            <div className="tracking-actions">

                                                {request.status === "PENDING" && (
                                                    <strong>Waiting for provider to accept</strong>
                                                )}

                                                {request.status === "ACCEPTED" && (
                                                    <strong>Provider accepted the request</strong>
                                                )}

                                                {request.status === "IN PROGRESS" && (
                                                    <strong>Service is in progress</strong>
                                                )}

                                                {request.status === "COMPLETED" && (
                                                    <strong>Service Completed</strong>
                                                )}

                                              {request.status === "REJECTED" && (
    <div>
        <strong>Provider rejected this request.</strong>

        <button
            className="provider-action"
            style={{ marginTop: 10 }}
            onClick={async () => {
                try {
                    setSelectedRequest(request);
                    setAssignedProviderName("");
                    setRecommendedProviders([]);

                    // Fetch a fresh list instead of relying on possibly empty state.
                    const response = await getProviders();
                    const allProviders = Array.isArray(response) ? response : [];
                    setProviders(allProviders);

                    const normalize = value =>
                        String(value || "").trim().toLowerCase().replace(/\s+/g, " ");
                    const service = normalize(request.serviceType);
                    const location = normalize(request.location);

                    // Never offer the provider who rejected this request.
                    const alternatives = allProviders.filter(provider => {
                        const providerId = provider.id ?? provider.providerId;
                        const rejectedProvider = request.providerId != null &&
                            String(providerId) === String(request.providerId);
                        return !rejectedProvider &&
                            normalize(provider.serviceType) === service;
                    });

                    // Prefer matching location, but don't hide valid service providers
                    // if location labels differ (e.g. Hyderabad vs Hyderabad City).
                    const sameLocation = alternatives.filter(provider => {
                        const providerLocation = normalize(provider.location);
                        return !location || !providerLocation ||
                            providerLocation.includes(location) || location.includes(providerLocation);
                    });

                    const finalProviders = sameLocation.length > 0 ? sameLocation : alternatives;
                    setRecommendedProviders(finalProviders);

                    if (finalProviders.length === 0) {
                        alert(`No alternative ${request.serviceType || "service"} providers were found. Check that providers exist for this service in the database.`);
                    } else {
                        // Bring the recommendations section into view after React renders it.
                        setTimeout(() => {
                            document.querySelector(".provider-section")?.scrollIntoView({
                                behavior: "smooth",
                                block: "start"
                            });
                        }, 100);
                    }
                } catch (error) {
                    console.error("Could not load alternative providers:", error);
                    alert("Could not load alternative providers: " + error.message);
                }
            }}
        >
            Choose Another Provider
        </button>
    </div>
)}

                                            </div>

                                            {request.status === "COMPLETED" && (
                                                <div className="tracking-card" style={{ marginTop: 18, background: "#f8fafc" }}>
                                                    <h3>Rate Your Service</h3>
                                                    {reviewingRequestId === request.id ? (
                                                        <>
                                                            <div style={{ display: "flex", gap: 8, margin: "12px 0" }}>
                                                                {[1,2,3,4,5].map(star => (
                                                                    <button
                                                                        key={star}
                                                                        type="button"
                                                                        onClick={() => setReviewRating(star)}
                                                                        style={{ border: "none", background: "transparent", fontSize: 28, cursor: "pointer", opacity: star <= reviewRating ? 1 : 0.35 }}
                                                                    >⭐</button>
                                                                ))}
                                                            </div>
                                                            <textarea
                                                                value={reviewFeedback}
                                                                onChange={(e) => setReviewFeedback(e.target.value)}
                                                                placeholder="Write your feedback..."
                                                                rows={3}
                                                                style={{ width: "100%", boxSizing: "border-box", padding: 12, border: "1px solid #d8dee9", borderRadius: 10, resize: "vertical" }}
                                                            />
                                                            <button
                                                                style={{ marginTop: 10 }}
                                                                onClick={async () => {
                                                                    try {
                                                                        if (!request.providerId) {
                                                                            alert("No provider is assigned to this request.");
                                                                            return;
                                                                        }
                                                                        await createReview({
                                                                            requestId: request.id,
                                                                            providerId: request.providerId,
                                                                            rating: reviewRating,
                                                                            feedback: reviewFeedback
                                                                        });
                                                                        alert("Review submitted successfully.");
                                                                        setReviewingRequestId(null);
                                                                        setReviewFeedback("");
                                                                        await loadRequests();
                                                                        const data = await getProviders();
                                                                        setProviders(data);
                                                                    } catch (error) {
                                                                        alert(error.message);
                                                                    }
                                                                }}
                                                            >
                                                                Submit Review
                                                            </button>
                                                        </>
                                                    ) : (
                                                        <button onClick={() => setReviewingRequestId(request.id)}>
                                                            ⭐ Rate Provider
                                                        </button>
                                                    )}
                                                </div>
                                            )}

                                        </>

                                    );

                                })()}

                            </div>

                        )}



                        {/* REQUEST HISTORY */}

                        {showHistory && (

                            <div className="history-section">

                                <h3>
                                    Service History
                                </h3>


                                {requests
                                    .slice()
                                    .reverse()
                                    .map(
                                        (request) => (

                                            <div
                                                className="history-card"
                                                key={request.id}
                                            >

                                                <div>

                                                    <strong>
                                                        {request.serviceType}
                                                    </strong>

                                                    <p>
                                                        {request.description}
                                                    </p>

                                                </div>


                                                <span>
                                                    {request.status}
                                                </span>

                                            </div>

                                        )
                                    )}

                            </div>

                        )}

                    </div>

                )}

            </main>

               </div>
        )}

     
{/* PROVIDER DASHBOARD */}
{isLoggedIn && userRole === "PROVIDER" && (
    <div className="provider-dashboard">
<div className="provider-topbar">
            <div className="provider-brand">
                <div className="provider-brand-icon">🔧</div>
                <div>
                    <h1>Fixora AI</h1>
                    <p>Provider Service Console</p>
                </div>
            </div>
            <button className="provider-logout" onClick={handleLogout}>
                Logout
            </button>
        </div>

        {!selectedProvider ? (
            <>
                <div className="provider-hero">
                    <div>
                        <h2>Provider Dashboard</h2>
                        <p>Search and manage service businesses and customer requests.</p>
                    </div>
                    <div className="provider-count">
                        {providers.length} Services
                    </div>
                </div>

                <div className="provider-toolbar">
                    <input
                        className="provider-search"
                        type="text"
                        placeholder="Search services, businesses, or locations..."
                        value={providerSearch}
                        onChange={(e) => setProviderSearch(e.target.value)}
                    />
                    <button className="provider-search-btn">
                        🔍 Search
                    </button>
                </div>

                <div className="provider-grid">
                    {providers
                        .filter(provider => {
                            const q = providerSearch.trim().toLowerCase();
                            if (!q) return true;
                            return (
                                provider.name?.toLowerCase().includes(q) ||
                                provider.serviceType?.toLowerCase().includes(q) ||
                                provider.location?.toLowerCase().includes(q)
                            );
                        })
                        .map(provider => (
                            <div className="business-card" key={provider.id}>
                                <div className="business-icon">🛠️</div>
                                <h3>{provider.name}</h3>
                                <div className="business-meta">
                                    <div><strong>Service:</strong> {provider.serviceType}</div>
                                    <div><strong>Location:</strong> {provider.location}</div>
                                    <div><strong>Rating:</strong> ⭐ {provider.rating}</div>
                                    <div><strong>Estimated Price:</strong> ₹{provider.price}</div>
                                </div>
                                <button
                                    className="business-action"
                                    onClick={async () => {
                                        try {
                                            const data = await getProviderRequests(provider.id);
                                            const reviews = await getProviderReviews(provider.id);
                                            setProviderRequests(data);
                                            setProviderReviews(reviews);
                                            setSelectedProvider(provider);
                                        } catch (error) {
                                            console.error(error);
                                        }
                                    }}
                                >
                                    View Requests →
                                </button>
                            </div>
                        ))}
                </div>

                {providers.filter(provider => {
                    const q = providerSearch.trim().toLowerCase();
                    return !q || provider.name?.toLowerCase().includes(q) || provider.serviceType?.toLowerCase().includes(q) || provider.location?.toLowerCase().includes(q);
                }).length === 0 && (
                    <div className="provider-detail" style={{marginTop: 20, textAlign: "center"}}>
                        No services found for “{providerSearch}”.
                    </div>
                )}
            </>
        ) : (
            <div className="provider-detail">
                <button className="provider-back" onClick={() => { setSelectedProvider(null); setProviderReviews([]); }}>
                    ← Back to All Services
                </button>

                <div className="provider-hero">
                    <div>
                        <h2>{selectedProvider.name}</h2>
                        <p>{selectedProvider.serviceType} · {selectedProvider.location} · ⭐ {selectedProvider.rating}</p>
                    </div>
                </div>

                <div className="provider-summary-grid">
                    <div className="provider-summary-card">
                        <span className="summary-label">Total requests</span>
                        <strong>{providerRequests.filter(request => request.providerId === selectedProvider.id).length}</strong>
                        <span className="summary-note">Assigned to this provider</span>
                    </div>
                    <div className="provider-summary-card summary-completed">
                        <span className="summary-label">Completed jobs</span>
                        <strong>{providerRequests.filter(request => request.providerId === selectedProvider.id && request.status === "COMPLETED").length}</strong>
                        <span className="summary-note">Successfully completed</span>
                    </div>
                    <div className="provider-summary-card summary-rating">
                        <span className="summary-label">Customer rating</span>
                        <strong>{providerReviews.length ? (providerReviews.reduce((sum, review) => sum + Number(review.rating || 0), 0) / providerReviews.length).toFixed(1) : "—"}<small> / 5</small></strong>
                        <span className="summary-note">{providerReviews.length} customer review{providerReviews.length === 1 ? "" : "s"}</span>
                    </div>
                </div>

                <div className="business-details">
        <h2>{selectedProvider.name}</h2>

        <h3>Customer Reviews</h3>

        {providerReviews.length === 0 ? (
            <p>No reviews yet.</p>
        ) : (
            providerReviews.map(review => (
                <div className="review-card" key={review.id}>
                    <div>
                        {"⭐".repeat(review.rating)}
                    </div>

                    <p>
                        {review.feedback || "No feedback provided."}
                    </p>

                    <small>
                        {review.createdAt
                            ? new Date(review.createdAt)
                                .toLocaleDateString()
                            : ""}
                    </small>
                </div>
            ))
        )}
    </div>

                <h2>Service Requests</h2>
                {providerRequests.filter(request => request.providerId === selectedProvider.id).length === 0 ? (
                    <p>No requests for this service yet.</p>
                ) : (
                    <div className="request-grid">
                        {providerRequests
                            .filter(request => request.providerId === selectedProvider.id)
                            .map(request => (
                                <div className="provider-request-card" key={request.id}>
                                    <h3>{request.serviceType}</h3>
                                    <p><strong>Problem:</strong> {request.description}</p>
                                    <p><strong>Location:</strong> {request.location}</p>
                                    <p><strong>Status:</strong> <span className="status-pill">{request.status}</span></p>

                                    {request.status === "PENDING" && (
                                        <>
                                            <button className="provider-action" onClick={() => changeStatus(request.id, "ACCEPTED")}>
                                                Accept Request
                                            </button>
                                            <button className="provider-action reject-action" onClick={() => changeStatus(request.id, "REJECTED")}>
                                                Reject Request
                                            </button>
                                        </>
                                    )}
                                    {request.status === "ACCEPTED" && (
                                        <button className="provider-action" onClick={() => changeStatus(request.id, "IN PROGRESS")}>
                                            Start Job
                                        </button>
                                    )}
                                    {request.status === "IN PROGRESS" && (
                                        <button className="provider-action" onClick={() => changeStatus(request.id, "COMPLETED")}>
                                            Complete Job
                                        </button>
                                    )}
                                </div>
                            ))}
                    </div>
                )}

                <div className="review-card">
                    <h2 style={{marginTop: 0}}>Customer Feedback</h2>
                    {providerReviews.length === 0 ? (
                        <p>No customer reviews yet.</p>
                    ) : (
                        <>
                            <p><strong>Reviews:</strong> {providerReviews.length} · <strong>Average:</strong> ⭐ {(providerReviews.reduce((sum, r) => sum + Number(r.rating || 0), 0) / providerReviews.length).toFixed(1)}</p>
                            {providerReviews.map(review => (
                                <div className="review-item" key={review.id}>
                                    <div>⭐ {review.rating}/5</div>
                                    <p>{review.feedback || "No written feedback."}</p>
                                    <small>{review.createdAt ? new Date(review.createdAt).toLocaleString() : ""}</small>
                                </div>
                            ))}
                        </>
                    )}
                </div>

                <h2 style={{marginTop: 30}}>Job History</h2>
                {providerRequests.filter(request => request.providerId === selectedProvider.id && request.status === "COMPLETED").length === 0 ? (
                    <p>No completed jobs yet.</p>
                ) : (
                    <div className="request-grid">
                        {providerRequests
                            .filter(request => request.providerId === selectedProvider.id && request.status === "COMPLETED")
                            .map(request => (
                                <div className="provider-request-card" key={request.id}>
                                    <h3>{request.serviceType}</h3>
                                    <p><strong>Problem:</strong> {request.description}</p>
                                    <p><strong>Location:</strong> {request.location}</p>
                                    <p><strong>Status:</strong> <span className="status-pill">COMPLETED</span></p>
                                </div>
                            ))}
                    </div>
                )}
            </div>
        )}
    </div>
)}

</>
);
}

export default App;