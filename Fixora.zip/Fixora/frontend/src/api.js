const API_URL = "http://localhost:8080/api";

function getAuthHeaders() {
    const token = localStorage.getItem("token");
    return {
        "Content-Type": "application/json",
        ...(token && { Authorization: `Bearer ${token}` })
    };
}

/* ================= AUTH ================= */
export async function login(user) {
    const response = await fetch(`${API_URL}/users/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    });
    if (!response.ok) throw new Error("Login failed");
    const data = await response.json();
    localStorage.setItem("token", data.token);
    localStorage.setItem("role", data.role);
    localStorage.setItem("email", data.email);
    localStorage.setItem("userId", data.userId);
    return data;
}

export async function register(user) {
    const response = await fetch(`${API_URL}/users/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
    });
    if (!response.ok) throw new Error("Registration failed");
    return response.json();
}

/* ================= AI ================= */
export async function analyzeProblem(problem) {
    const response = await fetch(`${API_URL}/ai/analyze`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ problem })
    });
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "AI analysis failed");
    }
    return response.json();
}

/* ================= PROVIDERS ================= */
export async function getProviders() {
    const response = await fetch(`${API_URL}/providers`, {
        headers: getAuthHeaders()
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
        throw new Error(
            `Failed to load providers (${response.status}): ${
                typeof data === "string" ? data : JSON.stringify(data)
            }`
        );
    }

    console.log("Providers API response:", data);

    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.content)) return data.content;
    if (Array.isArray(data?.providers)) return data.providers;

    throw new Error("The providers API did not return a provider list.");
}
export async function findMatches(request) {
    const response = await fetch(`${API_URL}/matching`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(request)
    });
    if (!response.ok) throw new Error("Failed to find providers");
    return response.json();
}

/* ================= REQUESTS ================= */
export async function createRequest(request) {
    const response = await fetch(`${API_URL}/requests`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(request)
    });
    if (!response.ok) throw new Error("Failed to create service request");
    return response.json();
}

export async function getRequests() {
    const response = await fetch(`${API_URL}/requests`, { headers: getAuthHeaders() });
    if (!response.ok) throw new Error("Failed to get service requests");
    return response.json();
}

export async function updateRequestStatus(id, status) {
    const response = await fetch(
        `${API_URL}/requests/${id}/status?status=${encodeURIComponent(status)}`,
        { method: "PUT", headers: getAuthHeaders() }
    );
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to update request status");
    }
    return response.json();
}

export async function assignProvider(requestId, providerId) {
    const response = await fetch(
        `${API_URL}/requests/${requestId}/provider?providerId=${providerId}`,
        { method: "PUT", headers: getAuthHeaders() }
    );
    if (!response.ok) throw new Error("Failed to assign provider");
    return response.json();
}

/* ================= PROVIDER REQUESTS ================= */
export async function getProviderRequests(providerId) {
    const response = await fetch(`${API_URL}/requests/provider/${providerId}`, {
        headers: getAuthHeaders()
    });
    if (!response.ok) throw new Error("Failed to load provider requests");
    return response.json();
}

/* ================= BOOKINGS ================= */
export async function createBooking(booking) {
    const response = await fetch(`${API_URL}/bookings`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(booking)
    });
    if (!response.ok) throw new Error("Failed to create booking");
    return response.json();
}

export async function getBookings() {
    const response = await fetch(`${API_URL}/bookings`, { headers: getAuthHeaders() });
    if (!response.ok) throw new Error("Failed to get bookings");
    return response.json();
}

/* ================= REVIEWS ================= */
export async function createReview(review) {
    const response = await fetch(`${API_URL}/reviews`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(review)
    });
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to submit review");
    }
    return response.json();
}

export async function getProviderReviews(providerId) {
    const response = await fetch(`${API_URL}/reviews/provider/${providerId}`, {
        headers: getAuthHeaders()
    });
    if (!response.ok) throw new Error("Failed to load provider reviews");
    return response.json();
}